
export default function Footer() {
    return (
        <footer>
            <div className="container">
                <a href="https://komit.tech/" target="_blank" rel="noopener noreferrer">
                    Komit Tech
                </a>
            </div>
        </footer>
    )
}