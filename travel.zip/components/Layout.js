import React from 'react'
import Header from './Header'
import Footer from './Footer'

const Layout = ({ children, menu }) => {
    return (
        <div className='layout'>
            <Header menu={menu}/>
            {children}
            <Footer />
        </div>
    )
}

export default Layout