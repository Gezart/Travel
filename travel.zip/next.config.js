module.exports = {
    images: {
      domains: ['testg.devtest-demo.ch'],
    },
    // Other configurations can go here
  };
  